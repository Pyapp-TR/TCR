
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import sys

app = Ursina()

olusum_sirasi = 0
blok = 1
timer = 0

n_kol = "assets/kol.glb"
n_doner = "assets/doner_model.glb"
n_cami = "assets/cami_model.glb"
n_kahve = "assets/kahve_model.glb"
n_cay = "assets/cay_model.glb"
n_blok = "assets/cube.obj"

tx_cimen = load_texture("assets/cimen_skin.png")
tx_tas = load_texture("assets/tas_skin.png")
tx_odun = load_texture("assets/odun_skin.png")
tx_sert_tas = load_texture("assets/sert_tas_skin.png")
tx_toprak = load_texture("assets/toprak_skin.png")
tx_TURKIYE = load_texture("assets/Türk_bayrağı_skin.png")
tx_yaprak = load_texture("assets/yaprak_skin.png")

olusum = [
    tx_cimen,
    tx_toprak,
    tx_toprak,
    tx_tas,
    tx_tas,
    tx_sert_tas
]

kirilmaz = [tx_sert_tas]


class Voxel(Button):
    def __init__(
        self,
        rotation=0,
        position=(0, 0, 0),
        texture=tx_cimen,
        model=n_blok,
        scale=0.5
    ):
        super().__init__(
            parent=scene,
            position=position,
            model=model,
            origin_y=0.5,
            texture=texture,
            color=color.white,
            highlight_color=color.white,
            scale=scale,
            rotation=rotation
        )

        self.kirilma_suresi = 0

    def input(self, key):
        if self.hovered:
            if key == "right mouse down":
                if blok == 1:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_cimen,
                        model=n_blok
                    )

                elif blok == 2:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_tas,
                        model=n_blok
                    )

                elif blok == 3:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_odun,
                        model=n_blok
                    )

                elif blok == 4:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=None,
                        model=n_cay,
                        scale=0.1
                    )

                elif blok == 5:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=None,
                        model=n_kahve,
                        scale=0.1
                    )

                elif blok == 6:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_toprak,
                        model=n_blok
                    )

                elif blok == 7:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_TURKIYE,
                        model=n_blok
                    )

                elif blok == 8:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=None,
                        model=n_doner,
                        scale=0.5
                    )

                elif blok == 9:
                    Voxel(
                        position=self.position + mouse.normal,
                        texture=tx_yaprak,
                        model=n_blok,
                        scale=0.5
                    )

    def update(self):
        if mouse.hovered_entity == self and held_keys["left mouse"]:
            if self.texture not in kirilmaz:
                self.kirilma_suresi += time.dt

                ilerleme = min(self.kirilma_suresi / 1, 1)

                self.color = color.rgb(
                    1,
                    1 - ilerleme,
                    1 - ilerleme
                )

                if self.kirilma_suresi >= 1:
                    destroy(self)
        else:
            self.kirilma_suresi = 0
            self.color = color.white


player = FirstPersonController(scale=(1, 1, 1))


def envanter_gorev():
    envanter.position = mouse.position


envanter = Button(
    texture="assets/gui/envanter.png",
    parent=camera.ui,
    on_click=envanter_gorev,
    color = color.white,
    highlight_color = color.white,
    position = (0.1,-0.2),
    scale = (1,1),
)

envanter.enabled = False

startGame_started = False


def startGame():
    global olusum_sirasi

    for olusum_sirasi in range(len(olusum)):
        for z in range(10):
            for x in range(10):
                Voxel(
                    position=(x, -olusum_sirasi, z),
                    model=n_blok,
                    texture=olusum[olusum_sirasi]
                )


startGame()


def input(key):
    if key == "e":
        envanter.enabled = not envanter.enabled

        if envanter.enabled:
            mouse.locked = False
            mouse.visible = True
        else:
            mouse.locked = True
            mouse.visible = False

    if key == "escape":
        sys.exit()


def update():
    global blok

    if held_keys["1"]:
        blok = 1
    if held_keys["2"]:
        blok = 2
    if held_keys["3"]:
        blok = 3
    if held_keys["4"]:
        blok = 4
    if held_keys["5"]:
        blok = 5
    if held_keys["6"]:
        blok = 6
    if held_keys["7"]:
        blok = 7
    if held_keys["8"]:
        blok = 8
    if held_keys["9"]:
        blok = 9
    if held_keys["0"]:
        blok = 10

    if held_keys["left shift"]:
        player.speed = 6
    else:
        player.speed = 4


app.run()
